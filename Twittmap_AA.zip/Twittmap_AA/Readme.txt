
The following documentation and tutorials were refered in completing this project.


1) Elastic Search, https://www.elastic.co/, accessed on March, 2016.
2) Nodejs.es, http://nodejs-es.github.io/api/stream.html, accessed on March, 2016.
3) Revisting charts: NodeJS, Twitter and Elasticsearch, http://hardlifeofapo.com/revisiting-charts-nodejs-twitter-elasticsearch/, accessed on March, 2016.
4) Using the Twitter Stream API to Visualize Tweets on Google Maps,http://blog.safe.com/2014/03/twitter-stream-api-map/, accessed on March, 2016.
5) Github repository: safesoftware/twitter-streaming-nodejs, https://github.com/safesoftware/twitter-streaming-nodejs, accessed on March, 2016.
