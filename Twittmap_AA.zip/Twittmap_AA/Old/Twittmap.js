/**
 * Module dependencies.
 */

var Xpress = require('express')
  , Path = require('path')
  , Date1 = require('moment')                                       //library for manipulation of dates and time
  , twitter = require('twitter')
  , io = require('socket.io').listen(server)
  , http = require('http');
  
//var favicon = require('serve-favicon');

// var child_process = require('child_process');

// // exec: spawns a shell.
// var a=child_process.exec(__dirname+'/elasticsearch-2.2.0/bin/elasticsearch.bat', function(error, stdout, stderr){
//     console.log("Error:"+error);
//     console.log("STDOUT:"+stdout);
//     setTimeout(function() {
//         console.log('hello world!');
//     }, 5000);
// });


//Declare the variables to be used 

var global_socket, global_stream, client;

var Kword = 'All';

//Including elasticsearch module
var elasticsearch = require('elasticsearch');

//Declaring the keys and creating a new instance of twitter object with these keys

var consumer_key = "jBMK4PGxrtt6oMF6zhrBoco1k"
var consumer_secret = "sQOWRvCArfP7clj5QL7zJbeb7jQT74dlPHbFsoGVOEwhAKD8ov"
var access_token_key = "494965165-a4b5V4XZVmvBKJISajjbLTSoZqAxyb6YM6qdhek1"
var access_token_secret = "5HzRmG55vEG5Iey5UZAOyoeOb5VBwQfV5iOou0OMPvr9C"

var Login = new twitter ({consumer_key : consumer_key , consumer_secret : consumer_secret, 
  access_token_key : access_token_key, access_token_secret : access_token_secret });




var twittmap_app = Xpress();     //Setting up an express app using the Xpress object of the express module

var server = http.createServer(twittmap_app);

var io = io.listen(server)

var Stm = null;

var Prev_Kword = '';


//server.listen(process.env.PORT || 8081);

//Setup Elastic Search
var client = new elasticsearch.Client(
{
    host: 'localhost:9200',
    log : 'trace'
  });


  //twittmap_app.set('port', process.env.PORT || 8081);
  //twittmap_app.set('views', __dirname + '/views');
  //twittmap_app.set('view engine', 'jade');                                  //Setting up default view engine for the twittmap_app
  //twittmap_app.use(favicon());
  //twittmap_app.use(favicon(__dirname + '/public/favicon.ico'));
  //twittmap_app.use(bodyParser());
  //twittmap_app.use(Xpress.methodOverride());
  //twittmap_app.use(twittmap_app.router);
  //twittmap_app.use(Xpress['static'](Path.join(__dirname, 'public')));      //Setting up routing for the twittmap_app
  //twittmap_app.use(Xpress.logger('dev'));
  twittmap_app.use(Xpress.static(__dirname + '/public'));



client.ping({
    requestTimeout: 30000,


    hello: "elasticsearch"
}, function (error) {
    if (error) {
        console.error('Not Working');
    } else {
        console.log('Working!!!!!');
    }
});


client.indices.delete({index: 'tweets'});
client.indices.create({
    index: 'tweets',
    body: {
        "mappings": {
            "All": {
                "properties": {
                    "coordinates": {"type": "geo_point"},
                    "text": {"type": "string"},
                   // "created_at" : {"type" : "date"}
                }
            },
            "Cricket": {
                "properties": {
                    "coordinates": {"type": "geo_point"},
                    "text": {"type": "string"},
                    //"created_at" : {"type" : "date"}
                }
            },
            "Election": {
                "properties": {
                    "coordinates": {"type": "geo_point"},
                    "text": {"type": "string"},
                    //"created_at" : {"type" : "date"}
                }
            },
            "Oscars": {
                "properties": {
                    "coordinates": {"type": "geo_point"},
                    "text": {"type": "string"},
                    //"created_at" : {"type" : "date"}
                }
            },
            "Climate": {
                "properties": {
                    "coordinates": {"type": "geo_point"},
                    "text": {"type": "string"},
                    //"created_at" : {"type" : "date"}
                }
            },
            "Humanity": {
                "properties": {
                    "coordinates": {"type": "geo_point"},
                    "text": {"type": "string"},
                    //"created_at" : {"type" : "date"}
                }
            },
            "Dog": {
                "properties": {
                    "coordinates": {"type": "geo_point"},
                    "text": {"type": "string"},
                   // "created_at" : {"type" : "date"}
                }
            },
            "Concerts": {
                "properties": {
                    "coordinates": {"type": "geo_point"},
                    "text": {"type": "string"},
                    //"created_at" : {"type" : "date"}
                }
            },
            "GoT": {
                "properties": {
                    "coordinates": {"type": "geo_point"},
                    "text": {"type": "string"},
                    //"created_at" : {"type" : "date"}
                }
            }
        }
    }
});



function FetchNearByTweets(socket,data)
  {

  data.lat = Math.round(data.lat * 100000) / 100000;
  data.lng = Math.round(data.lng * 100000) / 100000;
  
  client.indices.refresh({index:'tweets'});


  client.search(
  {
    index: 'tweets',
    type: Kword,
    body: 
    {
      "query": 
      {
        "filtered": 
        {
          "query" : 
          {
            "match_all" : {}
          },
          "filter" :
          {
            "geo_distance" : 
            {
              "distance" : "300km",
              "coordinates" : 
              {
                "lat" : data.lat,
                "lon" : data.lng
              }
            }
          }
        }
      },
    
    }    
  }).then (function (response)
  {
    var Computed = response.hits.hits.map(function(h)
    {
      console.log(h._source.text);
      var MsgOut = {"lat" : h._source.coordinates[0],"lng" : h._source.coordinates[1]};

      socket.broadcast.emit("close-tweets", MsgOut);
      socket.emit('close-tweets', MsgOut);

      //broadcastTweet(socket,MsgOut);

      //emitTweet(socket, MsgOut);

    });

  }, function (err)
  {
    
    console.error(err);
    console.log(err);

  });

}




//Kword = 'All';

//Filters = {'locations':'-180,-90,180,90', 'track' : Kword};

server.listen(process.env.PORT || 8081);


function FetchTwittData (S, data)
{
Filters = {'locations':'-180,-90,180,90', 'track' : Kword};


if(Stm == null)
{
  Stm = Login.stream('statuses/filter', Filters ,  function(stream) 
  {   
      stream.setMaxListeners(200000);
      
      //global_stream = stream;
      // stream.on('error', function(a,b)
      // {
      //   console.error(a);
      //   console.error(b);
      // });

    stream.on('data', function (data) 

    {

    if(Kword==Prev_Kword)
    {   
        //Check if the streamed result has coordinates

        if(data.coordinates)
        {
          if(data.coordinates != null)
          {

            var MsgOut = {"lat": data.coordinates.coordinates[0], "lng": data.coordinates.coordinates[1]};
            
            S.broadcast.emit("twitter-stream",MsgOut);
           // broadcastTweet(S, MsgOut);
                    S.emit('twitter-stream', MsgOut);
                        client.index({
                            index: 'tweets',
                            type: Kword,
                            id: data.id,
                            body: {"text": data.text, "coordinates": data.coordinates.coordinates}
                        }, function (error, response) {
                            console.log(response);
                        });

           // emitTweet(S, MsgOut);

          // saveIntoElasticSearch(data, Kword, emitTweet);

          }

          else if(data.place)
          {

            if(data.place.bounding_box === 'Polygon')
            {
              // Calculate the center of the bounding box for the tweet
                 var GeoDim, i, l;
                 var mLat = 0;
                 var mLng = 0;
                 for (i= 0, l = GeoDim.length; i < l; i++) 
                 {                                  
                  GeoDim = GeoDim[i];
                  mLat += GeoDim[0];
                  mLng += GeoDim[1];
                 
                 }
                
                 mLat = mLat / GeoDim.length;
                 mLng = mLng / GeoDim.length;

                 // Build json object and broadcast it
                 var MsgOut = {"lat": mLat,"lng": mLng};
                 S.broadcast.emit("twitter-stream", MsgOut);

                 //broadcastTweet(S, MsgOut);
                 
            }
          }

        }

       stream.on('limit', function(limitMessage) 
        {
        
         return console.log(limitMessage);
        
        });

       stream.on('warning', function(warning) 
       {

         return console.log(warning);
       
       });

       stream.on('disconnect', function(disconnectMessage) 
       {
       
         return console.log(disconnectMessage);
       
       });

}
else
    {
      stream.destroy();
      Stm=null;
      Prev_Kword=Kword;
      FetchTwittData(S,data);
    }

      });


  });
}

}






function saveIntoElasticSearch(aTweet, Kword, callback)
{
  var Key = aTweet.id;
  var myDate = Date1(aTweet.created_at);
  aTweet.created_at = myDate;
  
  client.index({
    index: 'tweets',
    type: Kword,
    id: Key,
    body: { "text" : aTweet.text, "coordinates" : aTweet.coordinates.coordinates, "created_at" : aTweet.created_at}
  }, function (err, resp) {
    console.info(err);
    console.info(resp);
    console.log(resp);
    if(!err){
      callback(aTweet);}
  });

}






/* Socket Config */
io.sockets.on('connection', function (S) 
{
  //global_socket = socket;
  
  // Set up events on socket
  
  // Start
  S.on("start tweets", function(data) 
  {

    FetchTwittData (S, data)

  });



  S.on("category change",function(data)
  {
  
        Kword=data;

        //FetchTwittData (S, data)


        //Filters = {'locations':'-180,-90,180,90', 'track' : Kword}; // Location tags spanning the globe
  
  });
  

  //Get Near by data
  S.on("click happened", function(data)
  {
    
    FetchNearByTweets(S,data);
    
  });

  S.emit("connected");

});


/* Run server  */

//server.listen(process.env.PORT || 8081);





